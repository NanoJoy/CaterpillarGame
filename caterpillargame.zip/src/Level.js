function Level(layout, leafPointers, music, dialogues, lampNames, powerupNames, redDragDirections) {
    this.layout = layout;
    this.leafPointers = leafPointers;
    this.music = music;
    this.dialogues = dialogues;
    this.lampNames = lampNames;
    this.powerupNames = powerupNames;
    this.redDragDirections = redDragDirections;
}