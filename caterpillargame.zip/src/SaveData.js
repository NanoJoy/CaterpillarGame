var SaveData = {
    newGame: true,
    dialogueStates: {},
    areaNumber: -1,
    map: [],
    lampName: "",
    lampPos: [],
    keysHad: {
        colors: [],
        counts: []
    },
    lichenCount: 0,
    powerups: []
};